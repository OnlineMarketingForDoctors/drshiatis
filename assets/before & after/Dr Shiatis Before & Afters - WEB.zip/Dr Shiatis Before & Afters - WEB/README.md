# Dr Shiatis — Before & After photos, prepared for web

Generated from `Dr Shiatis Before & Afters`. **Originals were not modified.**

## What's here

- **64 before/after pairs** across **25 patients / 11 procedures** — 128 images
- Every image: **1200 × 1500 px (4:5 portrait), WebP, quality 82, all EXIF stripped**
- `_Social Graphics/` — 31 pre-made Instagram before/after collages, converted to WebP (max 1200px, native ratio). Not for gallery sliders.
- `manifest.csv` — every output file mapped back to its source, with source pixel size and the scale factor applied.

## Folder & file naming

```
<Procedure>/patient-NN/before-<angle>.webp
                       after-<angle>.webp
```

Angles used: `front`, `oblique-left`, `oblique-right`, `side-left`, `side-right`, `back`.
Left/right describe the direction the patient is turned in frame. Each angle always exists as a
matched before **and** after — there are no orphans, so a slider can pair them by filename.

Patient numbers are sequential per procedure and **do not** match the original folder numbering
(the originals contained duplicated folders and misfiled patients; these were consolidated).

## How the selection was made

Kept: clean standing clinical photographs where the same angle exists both before and after.
Left out: intra-operative / on-table photographs, close-ups of dressings or incisions, phone
screenshots, duplicate and lower-resolution copies of the same shot, video files, PDFs and
documents, and any angle with no counterpart on the other side.

Cropping is a centred 4:5 crop then Lanczos resize. Most sources were 3:4, so roughly 6% was
trimmed from the top and bottom — framing is preserved.

## Points to check before publishing

1. **Four images were upscaled** (source smaller than 1200×1500). All are mild, but worth a look:
   `FTM Top Surgery/patient-01` before-front / before-oblique-left / before-oblique-right (≈1.5×),
   and `Breast Augmentation/patient-03` after-oblique-right (≈1.4×).
2. **Burned-in text.** `Breast Augmentation Mastopexy/patient-02` carries "Before"/"After" captions
   baked into the source images. Nothing else does.
3. **Surgical marker pen** is visible on the before photos of most gynaecomastia patients, and the
   afters for those patients are immediate post-operative (same day), some with dressings or
   bruising. That is how the source set was shot — flag if you'd rather show healed results only.
4. **Patient-supplied before photos.** `360 Lipo + Renuvion/patient-01` befores are home photographs,
   so lighting and background differ markedly from the clinic afters.
5. **Consent.** Faces are visible in a number of images, as requested. Confirm photographic consent
   covers web publication before these go live.

## Patients left out entirely, and why

| Original folder | Reason |
|---|---|
| gynaecomastia / patient 4 | No post-operative photographs — before only |
| gynaecomastia / patient 5 | Intra-operative draped shots only; no usable before |
| gynaecomastia / patient 7 | Before photos are low-resolution landscape crops (≤717 px tall) |
| gynaecomastia / patient 11 | Before photos are mirror selfies with the phone in frame |
| Breast Lift (mastopexy) 1 | All sources 600 × 400 px — far below output size |
| Breast Lift (mastopexy) 2 | After photos 510 × 340 / 600 × 400 px |
| body lift | Before photos 600 × 400 px |
| tummy tuck 1 | No after photograph |
| neck lipo / patient 1 | Only finished collages exist, no separate before/after files |
| Brachioplasty arm lift + J-Plasma | Only a stacked screenshot collage |

The collages for these patients are still in `_Social Graphics/`. Four of them (Breast Lift 1,
Breast Lift 2, body lift, tummy tuck) are strong cases — **if higher-resolution originals exist,
send them over and they can be added to the gallery.**

## Duplicate folders found in the source

These held the same patient under more than one name and were consolidated:
`gynaecomastia 1`, `gynaecomastia 2`, `neck lipo/patient 2_` (all = gynaecomastia patient 2);
`Breast Augmentation Mastopexy 1/patient 4` and `Breast Augmentation 6/patient 4`
(both subsets of `Breast Lift (mastopexy) 4 with fat transfer`);
`Breast Lift (mastopexy) 1/patient 3 _` (= gynaecomastia patient 3);
`patient 1 _ arm lift + j plasma` (= Brachioplasty arm lift).
